/* =====================================================================
   Rivett Architectural — homepage interactions
   Reuses existing project libraries: jQuery, Bootstrap bundle, Owl Carousel.
   No new libraries introduced.
   ===================================================================== */
(function ($) {
  "use strict";

  $(function () {

    /* ---------- Mobile navigation toggle ---------- */
    var $body = $("body");
    var $toggle = $("#navToggle");

    // Backdrop for the off-canvas mobile menu
    if (!$(".nav-backdrop").length) {
      $body.append('<div class="nav-backdrop"></div>');
    }
    var $backdrop = $(".nav-backdrop");

    function closeNav() {
      $body.removeClass("nav-open");
      $toggle.attr("aria-expanded", "false");
    }

    // Toggle only when the burger (not the call link) is tapped
    $toggle.on("click", function (e) {
      if ($(e.target).closest(".nav-toggle-call").length) {
        return; // let the tel: link work
      }
      e.preventDefault();
      var open = $body.toggleClass("nav-open").hasClass("nav-open");
      $toggle.attr("aria-expanded", open ? "true" : "false");
    });

    $backdrop.on("click", closeNav);

    // Close the menu after choosing a link, and on desktop resize
    $("#mainNav a").on("click", closeNav);
    $(window).on("resize", function () {
      if (window.innerWidth > 991) closeNav();
    });

    /* ---------- Brand logo carousel (Owl) ---------- */
    if ($.fn.owlCarousel && $(".brand-logo-carousel").length) {
      $(".brand-logo-carousel").owlCarousel({
        loop: true,
        margin: 40,
        dots: false,
        nav: false,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        slideTransition: "linear",
        responsive: {
          0:    { items: 2 },
          576:  { items: 3 },
          768:  { items: 4 },
          992:  { items: 5 },
          1200: { items: 6 }
        }
      });
    }

    /* ---------- Testimonials carousel (Owl) ---------- */
    if ($.fn.owlCarousel && $(".testimonial-carousel").length) {
      $(".testimonial-carousel").owlCarousel({
        loop: true,
        margin: 24,
        dots: false,
        center:true,
        nav: true,
        navText: [
          '<img src="./src/images/testimonial-arrow.webp" alt="" width="50" height="50" class="img-fluid">',
          '<img src="./src/images/testimonial-arrow.webp" alt="" width="50" height="50" class="img-fluid" style="transform: rotate(180deg);">'
        ],
        responsive: {
          0:   { items: 1, margin:15, },
          768: { items: 2, margin:15,},
          992: { items: 3 },
          1200:{ items: 3 },
          1600:{items:4}
        }
      });
    }

    /* ---------- Mobile-only carousels (gallery + associations) ---------- */
    /* Both blocks keep their existing layout on desktop and become Owl
       carousels below 768px, using the same configuration as the brand strip.
       The owl-carousel classes are applied here rather than in the markup:
       Owl's stylesheet hides .owl-carousel until it is initialised, so a
       permanent class in the HTML would blank both sections out on desktop. */
    var MOBILE_QUERY = "(max-width: 767.98px)";

    var mobileCarousels = [
      { el: ".gallery-grid", margin: 12, responsive: { 0: { items: 1, stagePadding: 40,center:true }, 576: { items: 2 } } },
      { el: ".assoc-list",   margin: 30, responsive: { 0: { items: 2.2, stagePadding: 15,center:true }, 576: { items: 3 } } }
    ];

    function syncMobileCarousels() {
      if (!$.fn.owlCarousel) return;

      var isMobile = window.matchMedia(MOBILE_QUERY).matches;

      mobileCarousels.forEach(function (cfg) {
        $(cfg.el).each(function () {
          var $el = $(this);
          var running = $el.hasClass("owl-loaded");

          if (isMobile && !running) {
            $el.addClass("owl-carousel owl-theme").owlCarousel({
              loop: true,
              margin: cfg.margin,
              dots: false,
              nav: false,
              autoplay: true,
              autoplayTimeout: 2500,
              autoplayHoverPause: true,
              slideTransition: "linear",
              responsive: cfg.responsive
            });
          } else if (!isMobile && running) {
            // destroy.owl.carousel restores the original children, but the two
            // classes added above are ours to clean up.
            $el.trigger("destroy.owl.carousel").removeClass("owl-carousel owl-theme");
          }
        });
      });
    }

    syncMobileCarousels();

    var carouselResizeTimer;
    $(window).on("resize", function () {
      clearTimeout(carouselResizeTimer);
      carouselResizeTimer = setTimeout(syncMobileCarousels, 200);
    });

    /* ---------- Tabs (gallery + communities) ---------- */
    $(".rv-tabs").on("click", ".rv-tab", function () {
      var $tab = $(this);
      var target = $tab.data("tab");
      var $group = $tab.closest("section");

      $tab.addClass("active").attr("aria-selected", "true")
          .siblings(".rv-tab").removeClass("active").attr("aria-selected", "false");

      $group.find(".rv-tab-panel").each(function () {
        var isTarget = this.id === target;
        $(this).toggleClass("active", isTarget).prop("hidden", !isTarget);
      });

      // A carousel initialised inside a hidden panel has no width to measure,
      // so re-measure it the moment its panel becomes visible.
      $group.find(".rv-tab-panel.active .owl-loaded").trigger("refresh.owl.carousel");
    });

    /* ---------- Smooth scroll for in-page anchors ---------- */
    $('a[href^="#"]').on("click", function (e) {
      var id = $(this).attr("href");
      if (id.length <= 1) return;
      var $target = $(id);
      if ($target.length) {
        e.preventDefault();
        var offset = $(".site-header").outerHeight() || 0;
        $("html, body").animate(
          { scrollTop: $target.offset().top - offset - 10 },
          400
        );
      }
    });

  });
})(jQuery);


document.querySelectorAll('.rv-acc-head').forEach(label => {
  label.addEventListener('click', function(e) {
    const input = document.getElementById(this.getAttribute('for'));

    // If already checked → uncheck it (close)
    if (input.checked) {
      e.preventDefault();
      input.checked = false;
    }
  });
});

